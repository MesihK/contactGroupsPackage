import sys
from . import common.commp as cp

def main():


if __name__=='__main__':
    main()
