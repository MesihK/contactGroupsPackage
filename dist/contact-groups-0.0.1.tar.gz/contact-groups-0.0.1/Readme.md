# Contact Groups Packge

This package has multiple tools and individual functionalities to create bioinformatic
pipelines related to protein, multiple sequence alingment and sequence correlations.
